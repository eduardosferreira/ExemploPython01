n1 = int(input("Digite primeiro número: "))
n2 = int(input("Digite segundo número: "))
n3 = int(input("Digite terceiro número: "))

if  (n1 < n2 < n3):
    print ("crescente")
else:
    print ("não está em ordem crescente")