# CursoPython
codigos - Introdução à Ciência da Computação com Python - Universidade de São Paulo
