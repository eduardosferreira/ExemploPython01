import math
n = int(input("Digite o valor de n: "));
print(math.factorial(n))