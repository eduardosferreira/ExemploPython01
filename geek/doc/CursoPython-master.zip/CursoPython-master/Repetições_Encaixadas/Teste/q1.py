x = 1
cont = 0
while x < 3:
    y = 0
    while y <= 4:
        print(y) # Iteração
        y = y + 1
    x = x + 1