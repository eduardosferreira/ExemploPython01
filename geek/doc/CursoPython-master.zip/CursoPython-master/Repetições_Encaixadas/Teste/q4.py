x = 2
cont = 0
while x >= 0:
    y = 0
    while y >= 4:
        #comando qualquer
        print(y)
        y = y + 1
    x = x - 1