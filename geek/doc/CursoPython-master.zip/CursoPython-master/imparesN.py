n = int(input("Digite o valor de n: "))
count = 0
while count < n:
      print(2*count + 1)
      count += 1
