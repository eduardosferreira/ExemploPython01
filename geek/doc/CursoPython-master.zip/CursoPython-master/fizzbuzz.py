numero = int(input("Digite um número: "))
if (numero % 3 == 0) and (numero % 5 == 0):
    print ("FizzBuzz")
else:
    print (numero)