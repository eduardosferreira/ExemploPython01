valor = input("Digite o valor correspondente ao lado de um quadrado: ")
valorInt = int(valor)
x = 4*valorInt
y = valorInt ** 2
print ("perímetro: %d - área: %d " %(x,y))
