numero = int(input("Digite um número: "))
if (numero % 3 == 0):
    print ("Fizz")
else:
    print (numero)