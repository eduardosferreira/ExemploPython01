def total_Caracteres(x, y, z):
    return sum(len(x)+len(y)+len(z))



#testes
a = 'Jo'
b = 'di'
c = 'el'
print(total_Caracteres (a,b,c))
