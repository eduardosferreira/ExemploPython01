def maximo(x,y):
    if x > y:
        return x
    else:
        return y


# testes
print(maximo(4,2))
print(maximo(3,5))
print(maximo(0,-1))